///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

///Modified for MPU Wide Screen + Navigation

import 'package:flutter/material.dart';
import 'style.dart';

class JPGScreen extends StatelessWidget {
  const JPGScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xffffffff),

      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [

            /// JPG IMAGE (matches pubspec.yaml)
            Image.asset(
              'images/Cat.jpg',
              height: MediaQuery.of(context).size.height * 0.6,
              fit: BoxFit.contain,
            ),

            const SizedBox(height: 40),

            const Text(
              "JPG",
              style: AppStyle.titleStyle,
            ),

            const SizedBox(height: 40),

            SizedBox(
              width: AppStyle.buttonWidth,
              height: AppStyle.buttonHeight,
              child: MaterialButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                color: const Color(0xff3a57e8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Text(
                  "Back to Home",
                  style: AppStyle.buttonTextStyle,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}