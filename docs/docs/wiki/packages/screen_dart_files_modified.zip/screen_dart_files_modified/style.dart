import 'package:flutter/material.dart';

class AppStyle {

  /// ===== Wide Screen Sizes =====
  static const double titleSize = 40;
  static const double subtitleSize = 40;
  static const double buttonTextSize = 40;

  static const double buttonWidth = 400;
  static const double buttonHeight = 150;

  /// ===== Text Styles =====
  static const TextStyle titleStyle = TextStyle(
    fontWeight: FontWeight.w700,
    fontSize: titleSize,
    fontFamily: 'FiraCode',
    color: Color(0xff000000),
  );

  static const TextStyle subtitleStyle = TextStyle(
    fontWeight: FontWeight.w400,
    fontSize: subtitleSize,
    fontFamily: 'FiraCode',
    color: Color(0xff746f6f),
  );

  static const TextStyle buttonTextStyle = TextStyle(
    fontSize: buttonTextSize,
    fontFamily: 'FiraCode',
    fontWeight: FontWeight.w500,
    color: Colors.white,
  );
}