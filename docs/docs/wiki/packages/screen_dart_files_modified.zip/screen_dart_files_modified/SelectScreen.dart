///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

///Modified for MPU Wide Screen + Navigation

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'JPGScreen.dart';
import 'GIFScreen.dart';
import 'style.dart';

class SelectScreen extends StatelessWidget {
  const SelectScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: [

          /// CENTER CONTENT
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [

                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 30),
                  child: Text(
                    "Flutter Sample Application",
                    textAlign: TextAlign.center,
                    style: AppStyle.titleStyle,
                  ),
                ),

                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "Select the button below to view images in different formats.",
                    textAlign: TextAlign.center,
                    style: AppStyle.subtitleStyle,
                  ),
                ),

                const SizedBox(height: 50),

                /// JPG BUTTON
                SizedBox(
                  width: AppStyle.buttonWidth,
                  height: AppStyle.buttonHeight,
                  child: MaterialButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const JPGScreen()),
                      );
                    },
                    color: const Color(0xff3a57e8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: const Text(
                      "JPG",
                      style: AppStyle.buttonTextStyle,
                    ),
                  ),
                ),

                const SizedBox(height: 30),

                /// GIF BUTTON
                SizedBox(
                  width: AppStyle.buttonWidth,
                  height: AppStyle.buttonHeight,
                  child: MaterialButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const GIFScreen()),
                      );
                    },
                    color: const Color(0xff3a57e8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: const Text(
                      "GIF",
                      style: AppStyle.buttonTextStyle,
                    ),
                  ),
                ),
              ],
            ),
          ),

          /// EXIT BUTTON
          Positioned(
            top: 0,
            right: 0,
            child: MaterialButton(
              onPressed: () {
                SystemNavigator.pop();
              },
              color: const Color(0xffff0000),
              minWidth: 100,
              height: 100,
              child: const Text(
                "X",
                style: TextStyle(
                  fontSize: 40,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}