///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

import 'package:flutter/material.dart';
import 'dart:io';
import 'imagefiledisplay.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffffff),
      body: Align(
        alignment: Alignment(0.95, 0.5),
        //child: Padding(
        //  padding: EdgeInsets.fromLTRB(16, 50, 16, 16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: [
            Align(
                alignment: Alignment.centerRight,
                child: MaterialButton(
                  onPressed: () {
                    exit(0);
                  },
                  color: Color(0xfff20b0b),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                    side: BorderSide(color: Color(0xffc90c0c), width: 1),
                  ),
                  padding: EdgeInsets.all(16),
                  child: Text(
                    "X",
                    style: TextStyle(
                      fontSize: 40,
                      fontWeight: FontWeight.w400,
                      fontStyle: FontStyle.normal,
                    ),
                  ),
                  textColor: Color(0xfffdfcfc),
                  height: 80,
                  minWidth: 80,
                )),
            Expanded(
              flex: 1,
              child: Align(
                alignment: Alignment(-0.01, 0.2),
                child: Text(
                  "Flutter Sample Application",
                  textAlign: TextAlign.start,
                  overflow: TextOverflow.clip,
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,
                    fontSize: 50,
                    color: Color(0xff000000),
                    fontFamily: 'FiraCode',
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: Align(
                alignment: Alignment(-0.01, -1.4),
                child: Text(
                  "Choose a button to display an image",
                  textAlign: TextAlign.start,
                  overflow: TextOverflow.clip,
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,
                    fontSize: 50,
                    color: Color(0xff000000),
                    fontFamily: 'FiraCode',
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    flex: 1,
                    child: Align(
                      alignment: Alignment(0.2, -0.3),
                      child: MaterialButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ImageFileDisplay("JPEG"),
                            ),
                          );
                        },
                        color: Color.fromRGBO(8, 102, 168, 1),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                          side: BorderSide(
                            color: Color.fromRGBO(8, 102, 168, 1),
                            width: 1,
                          ),
                        ),
                        padding: EdgeInsets.all(16),
                        child: Text(
                          "JPEG",
                          style: TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.w400,
                            fontStyle: FontStyle.normal,
                            fontFamily: 'FiraCode',
                          ),
                        ),
                        textColor: Color(0xfffdfafa),
                        height: 150,
                        minWidth: 300,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Align(
                      alignment: Alignment(-0.2, -0.3),
                      child: MaterialButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ImageFileDisplay("GIF"),
                            ),
                          );
                        },
                        color: Color.fromRGBO(8, 102, 168, 1),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                          side: BorderSide(
                            color: Color.fromRGBO(8, 102, 168, 1),
                            width: 1,
                          ),
                        ),
                        padding: EdgeInsets.all(16),
                        child: Text(
                          "GIF",
                          style: TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.w400,
                            fontStyle: FontStyle.normal,
                            fontFamily: 'FiraCode',
                          ),
                        ),
                        textColor: Color(0xfffefdfd),
                        height: 150,
                        minWidth: 300,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.all(0),
              padding: EdgeInsets.all(0),
              width: 499,
              height: 280,
              decoration: BoxDecoration(
                color: Color(0x1ff8f8f8),
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.zero,
                border: Border.all(color: Color(0x4df9f9f9), width: 1),
              ),
            ),
          ],
        ),
        // ),
      ),
    );
  }
}
