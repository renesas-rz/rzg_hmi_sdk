///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

import 'package:flutter/material.dart';
import 'dart:io';
import 'imagefileselection.dart';

class ImageFileDisplay extends StatelessWidget {
  ImageFileDisplay(this.imagefile);
  String imagefile;
  Widget ifText() {
    if (imagefile == "JPEG") {
      return Image.asset(
        'images/Cat.jpg',
        height: 600,
        width: 1400,
        fit: BoxFit.contain,
      );
    } else if (imagefile == "GIF") {
      return Image.asset(
        'images/Moon.gif',
        height: 600,
        width: 1400,
        fit: BoxFit.contain,
      );
    } else {
      return const Text("");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffffff),
      body: Align(
        alignment: Alignment.center,
        // child: Padding(
        //   padding: EdgeInsets.fromLTRB(16, 50, 16, 16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Align(
                    alignment: Alignment(0.95, 0.2),
                    child: MaterialButton(
                      onPressed: () {
                        exit(0);
                      },
                      color: Color(0xfffb0404),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                        side: BorderSide(color: Color(0xff808080), width: 1),
                      ),
                      padding: EdgeInsets.all(16),
                      child: Text(
                        "X",
                        style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.w400,
                          fontStyle: FontStyle.normal,
                          fontFamily: 'FiraCode',
                        ),
                      ),
                      textColor: Color(0xfffcfafa),
                      height: 80,
                      minWidth: 80,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 1,
              child: Align(
                alignment: Alignment(-0.1, -0.3),
                child:

                    ///***If you have exported images you must have to copy those images in assets/images directory.
                    ifText(),
              ),
            ),
            Align(
              alignment: Alignment(0.95, -0.1),
              child: MaterialButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => MyHomePage()),
                  );
                },
                color: Color.fromRGBO(8, 102, 168, 1),
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                  side: BorderSide(color: Color(0xff808080), width: 1),
                ),
                padding: EdgeInsets.all(16),
                child: Text(
                  "Back",
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.w400,
                    fontStyle: FontStyle.normal,
                    fontFamily: 'FiraCode',
                  ),
                ),
                textColor: Color(0xfff9f7f7),
                height: 100,
                minWidth: 300,
              ),
            ),
          ],
        ),
        // ),
      ),
    );
  }
}
